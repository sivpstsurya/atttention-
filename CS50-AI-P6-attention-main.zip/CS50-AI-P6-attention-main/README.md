# CS50-AI-P6-attention
Second of the two projects for lecture 6 Language to "Artificial Intelligence with Python" Harvard course
